
public class InternetAddress {

}
