
public class Message {

}
